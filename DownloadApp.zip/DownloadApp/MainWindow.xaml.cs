﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;


namespace DownloadApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<DownloadItem> _downloads = new ObservableCollection<DownloadItem>();

        public MainWindow()
        {
            InitializeComponent();
            DownloadsListView.ItemsSource = _downloads;
        }

        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            /*
            var saveFileDialog = new Microsoft.Win32.SaveFileDialog();
            if (saveFileDialog.ShowDialog() == true)
            {
                SavePathTextBox.Text = saveFileDialog.FileName;
            }
            */

            // Используем FolderBrowserDialog для выбора директории
            var folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Select a folder to save the file",
                ShowNewFolderButton = true // Показывать кнопку создания новой папки
            };

            // Открываем диалог и проверяем, нажал ли пользователь OK
            if (folderBrowserDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                // Устанавливаем выбранную директорию в TextBox
                SavePathTextBox.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private async void StartButton_Click(object sender, RoutedEventArgs e)
        {
            var url = UrlTextBox.Text;
            var saveDirectory = SavePathTextBox.Text;
            var tags = TagsTextBox.Text;

            if (string.IsNullOrEmpty(url) || string.IsNullOrEmpty(saveDirectory))
            {
                System.Windows.MessageBox.Show("Please enter URL and save directory.");
                return;
            }

            // Извлекаем имя файла из URL
            var fileName = System.IO.Path.GetFileName(url);
            if (string.IsNullOrEmpty(fileName))
            {
                fileName = "downloaded_file_"+DateTime.Today.ToString()+"_"+ DateTime.Now.ToString(); // Имя по умолчанию, если не удалось извлечь из URL
            }

            var savePath = System.IO.Path.Combine(saveDirectory, fileName);

            var downloadItem = new DownloadItem
            {
                Url = url,
                SavePath = savePath,
                Tags = tags,
                Status = "Downloading"
            };

            _downloads.Add(downloadItem);

            try
            {
                await DownloadFileAsync(downloadItem);
            }
            catch (Exception ex)
            {
                downloadItem.Status = "Failed";
                System.Windows.MessageBox.Show($"Download failed: {ex.Message}");
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            var searchText = SearchTextBox.Text.ToLower();
            foreach (var item in _downloads)
            {
                if (item.Tags?.ToLower().Contains(searchText) == true)
                {
                    DownloadsListView.SelectedItem = item;
                    DownloadsListView.ScrollIntoView(item);
                    break;
                }
            }
        }

        private async Task DownloadFileAsync(DownloadItem downloadItem)
        {
            using (var webClient = new WebClient())
            {
                // Подписка на событие прогресса загрузки
                webClient.DownloadProgressChanged += (sender, e) =>
                {
                    downloadItem.Status = $"Downloading: {e.ProgressPercentage}%";
                };

                // Подписка на событие завершения загрузки
                webClient.DownloadFileCompleted += (sender, e) =>
                {
                    if (e.Error != null)
                    {
                        downloadItem.Status = "Failed";
                        System.Windows.MessageBox.Show($"Download failed: {e.Error.Message}");
                    }
                    else
                    {
                        downloadItem.Status = "Completed";
                    }
                };

                // Асинхронная загрузка файла
                await webClient.DownloadFileTaskAsync(new Uri(downloadItem.Url), downloadItem.SavePath);
            }
        }
    }
}
